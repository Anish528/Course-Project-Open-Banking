package com.tesobe.obp.domain;

import lombok.Data;

@Data
public class ATM {
    private String id;
    private Location location;
}
