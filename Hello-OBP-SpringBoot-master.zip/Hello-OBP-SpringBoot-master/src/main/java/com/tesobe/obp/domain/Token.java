package com.tesobe.obp.domain;

import lombok.Data;

@Data
public class Token {
    private String token;
}
