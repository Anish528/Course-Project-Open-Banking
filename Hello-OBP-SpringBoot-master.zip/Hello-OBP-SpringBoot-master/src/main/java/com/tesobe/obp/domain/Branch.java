package com.tesobe.obp.domain;

import lombok.Data;

@Data
public class Branch {
    private String id;
    private String name;
    private Location location;
}
